import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Foguete here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Foguete extends Actor
{
    private int timer = 0;
    /**
     * Act - do whatever the Foguete wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if(timer > 0){
        timer = timer - 1;
        }else{
        atirar();
        }
        mover();
    }
    
    public void mover()
    {
        if(Greenfoot.isKeyDown("left"))
            turn(-4);
        if(Greenfoot.isKeyDown("right"))
            turn(4);
    }
    
    public void atirar()
    {
        var MyWorld = (MyWorld)getWorld();
        if(Greenfoot.isKeyDown("space")){
        MyWorld.addObject(new Tiro(), getX() + 20, getY() + 20);
        timer = 30;
        }
    }
}
